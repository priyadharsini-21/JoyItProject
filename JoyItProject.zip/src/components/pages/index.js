import Homepage from "./Homepage";
import Store from "./Store";
import Basket from "./Basket"
export {Homepage, Store, Basket}

